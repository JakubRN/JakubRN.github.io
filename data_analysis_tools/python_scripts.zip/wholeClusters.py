import pandas as pd
# import numpy as np
import glob
import json
#from datetime import datetime
from collections import defaultdict
import sys
import os
def rec_dd():
    return defaultdict(rec_dd)

def readData(file):
    df = pd.read_csv(file)
    ds = df.to_dict('records')
    return ds


dict = rec_dd()

for file in glob.glob('ClusterData/*.csv'):
    print(file)
    result = os.path.basename(file).split('.')[0]
    dict[result[0]][result[3:5]][result[5:]][result[1:3]] = readData(file)

with open('wholeClusters.json', 'w') as f:
    json.dump(dict, f,)
sys.exit(0)
