# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
## --------------
## Read data file 
C <- read.csv("pa5dat02.csv", sep=',', head=TRUE)
## --------------------------------------------------------
## Change datetime format to enable mathematical operations
C$pickup_datetime <- as.POSIXct(C$pickup_datetime,tz='GMT')
C$dropoff_datetime <- as.POSIXct(C$dropoff_datetime,tz='GMT')
## ----------------------------------------------------------
## Add a column to separate between two time zones 
## Morning time - 22PM to 4AM, Night time - 6AM to 12PM 
require(lubridate)
Z <- data.frame(PickupHour=hour(C$pickup_datetime), 
                PickupDay=day(C$pickup_datetime), 
                PickupMonth=month(C$pickup_datetime), 
                DropoffHour=hour(C$dropoff_datetime), 
                DropoffDay=day(C$dropoff_datetime), 
                DropoffMonth=month(C$dropoff_datetime), 
                Quarter=C$quarter)
C$Daytime[(Z$PickupHour >= 0 & Z$PickupHour <= 4) | 
            Z$PickupHour >= 22] <- 0
C$Daytime[Z$PickupHour >= 6 & Z$PickupHour <= 12] <- 1
C2 <- C[C$Daytime==0 | C$Daytime==1,]
C2 <- C2[order(C2$pickup_datetime),]
C21 <- C2[C2$Daytime==0,]
C22 <- C2[C2$Daytime==1,]
# Check only for 2015 
startDate = as.Date('2015-01-01',tz='GMT')
endDate = as.Date('2015-12-31',tz='GMT')
D <- 0
E <- 0
counter <- 1
for(i in c(startDate:endDate)) {
  D[counter] <- sum(as.numeric(as.Date(C21$pickup_datetime)==i))
  E[counter] <- sum(as.numeric(as.Date(C22$pickup_datetime)==i))
  counter <- counter + 1
}
DayCount <- data.frame(Day = seq(as.Date("2015-01-01"), 
                                 as.Date("2015-12-31"), 
                                 by="days"), 
                       CountNight = D, CountDay = E)
rm(D,E)
par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(DayCount$Day, DayCount$CountNight, col=1, type='l', 
     main='Green Taxi Trip Count', xlab='observation', ylab='Count', 
     ylim=c(0,max(DayCount$CountNight)))
lines(DayCount$Day, DayCount$CountDay, col=2, type='l',lwd=2)
write.csv(DayCount, file = "pa5dat04.csv", row.names = FALSE)
