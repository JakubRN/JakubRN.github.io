#############################################################################
XQ1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ1H0p <- XQ1H0[XQ1H0$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ1H0d <- XQ1H0[XQ1H0$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ1H0p)
#write(exportJson, "ClusterData\\pC1Q1Night.json")
#rm(exportJson)
#exportJson <- toJSON(XQ1H0d)
#write(exportJson, "ClusterData\\dC1Q1Night.json")
ptmp <- XQ1H0p[sample(nrow(XQ1H0p), floor(0.15*dim(XQ1H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ1H0d[sample(nrow(XQ1H0d), floor(0.15*dim(XQ1H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
XQ1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ1H1p <- XQ1H1[XQ1H1$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ1H1d <- XQ1H1[XQ1H1$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ1H1p)
#write(exportJson, "ClusterData\\pC1Q1Day.json")
#rm(exportJson)
#exportJson <- toJSON(XQ1H1d)
#write(exportJson, "ClusterData\\dC1Q1Day.json")
ptmp <- XQ1H1p[sample(nrow(XQ1H1p), floor(0.15*dim(XQ1H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ1H1d[sample(nrow(XQ1H1d), floor(0.15*dim(XQ1H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q1H0p <- X2Q1H0[X2Q1H0$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q1H0d <- X2Q1H0[X2Q1H0$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q1H0p[sample(nrow(X2Q1H0p), floor(0.15*dim(X2Q1H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q1H0d[sample(nrow(X2Q1H0d), floor(0.15*dim(X2Q1H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q1H1p <- X2Q1H1[X2Q1H1$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q1H1d <- X2Q1H1[X2Q1H1$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q1H1p[sample(nrow(X2Q1H1p), floor(0.15*dim(X2Q1H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q1H1d[sample(nrow(X2Q1H1d), floor(0.15*dim(X2Q1H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q1H0p <- X3Q1H0[X3Q1H0$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q1H0d <- X3Q1H0[X3Q1H0$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q1H0p[sample(nrow(X3Q1H0p), floor(0.15*dim(X3Q1H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q1H0d[sample(nrow(X3Q1H0d), floor(0.15*dim(X3Q1H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q1H1p <- X3Q1H1[X3Q1H1$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q1H1d <- X3Q1H1[X3Q1H1$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q1H1p[sample(nrow(X3Q1H1p), floor(0.15*dim(X3Q1H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q1H1d[sample(nrow(X3Q1H1d), floor(0.15*dim(X3Q1H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q1H0p <- X4Q1H0[X4Q1H0$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q1H0d <- X4Q1H0[X4Q1H0$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q1H0p[sample(nrow(X4Q1H0p), floor(0.15*dim(X4Q1H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q1H0d[sample(nrow(X4Q1H0d), floor(0.15*dim(X4Q1H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q1H1p <- X4Q1H1[X4Q1H1$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q1H1d <- X4Q1H1[X4Q1H1$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q1H1p[sample(nrow(X4Q1H1p), floor(0.15*dim(X4Q1H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q1H1d[sample(nrow(X4Q1H1d), floor(0.15*dim(X4Q1H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q1H0p <- X5Q1H0[X5Q1H0$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q1H0d <- X5Q1H0[X5Q1H0$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q1H0p[sample(nrow(X5Q1H0p), floor(0.15*dim(X5Q1H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q1H0d[sample(nrow(X5Q1H0d), floor(0.15*dim(X5Q1H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q1H1p <- X5Q1H1[X5Q1H1$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q1H1d <- X5Q1H1[X5Q1H1$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q1H1p[sample(nrow(X5Q1H1p), floor(0.15*dim(X5Q1H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q1H1d[sample(nrow(X5Q1H1d), floor(0.15*dim(X5Q1H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q1H0p <- X6Q1H0[X6Q1H0$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q1H0d <- X6Q1H0[X6Q1H0$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q1H0p[sample(nrow(X6Q1H0p), floor(0.15*dim(X6Q1H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q1H0d[sample(nrow(X6Q1H0d), floor(0.15*dim(X6Q1H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q1H1p <- X6Q1H1[X6Q1H1$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q1H1d <- X6Q1H1[X6Q1H1$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q1H1p[sample(nrow(X6Q1H1p), floor(0.15*dim(X6Q1H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q1H1d[sample(nrow(X6Q1H1d), floor(0.15*dim(X6Q1H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(XQ1H1p$Pickup_longitude,XQ1H1p$Pickup_latitude, col=1, 
     type='p', main='Q1 Night Data', 
     xlab='Pickup longitude', ylab='Pickup latitude')
points(X2Q1H1p$Pickup_longitude,X2Q1H1p$Pickup_latitude, col=2)
points(X3Q1H1p$Pickup_longitude,X3Q1H1p$Pickup_latitude, col=3)
points(X4Q1H1p$Pickup_longitude,X4Q1H1p$Pickup_latitude, col=4)
points(X5Q1H1p$Pickup_longitude,X5Q1H1p$Pickup_latitude, col=5)
points(X6Q1H1p$Pickup_longitude,X6Q1H1p$Pickup_latitude, col=6)


