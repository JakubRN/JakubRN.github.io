# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
## --------------
## Read data file 
C <- read.csv("pa5dat01.csv", sep=',', head=TRUE)
## --------------------------------------------------------
## Change datetime format to enable mathematical operations
C$pickup_datetime <- as.POSIXct(C$pickup_datetime,tz='GMT')
C$dropoff_datetime <- as.POSIXct(C$dropoff_datetime,tz='GMT')
## ----------------------------------------------------------
## Fit kmeans to both pickup and dropoff locations 
fit <- kmeans(cbind(C$Pickup_longitude, C$Pickup_latitude), 
              6, nstart = 10, iter.max = 20)
write.csv(fit$centers, file = "PickupClusterCenters.csv", row.names = FALSE)
fit2 <- kmeans(cbind(C$Dropoff_longitude, C$Dropoff_latitude), 
               6, nstart = 10, iter.max = 20)
write.csv(fit2$centers, file = "DropoffClusterCenters.csv", row.names = FALSE)
C$pickup_cluster <- fit$cluster
C$dropoff_cluster <- fit2$cluster
C$quarter <- rep(0,1.2e6)
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-01-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-03-31',tz='GMT')] <- 1
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-04-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-06-30',tz='GMT')] <- 2
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-07-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-09-30',tz='GMT')] <- 3
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-10-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-12-31',tz='GMT')] <- 4
require(lubridate)
Z <- data.frame(PickupHour=hour(C$pickup_datetime), PickupDay=day(C$pickup_datetime), 
                PickupMonth=month(C$pickup_datetime), DropoffHour=hour(C$dropoff_datetime), 
                DropoffDay=day(C$dropoff_datetime), DropoffMonth=month(C$dropoff_datetime), 
                Quarter=C$quarter)
C$Daytime <- rep(-1,1.2e6)
C$Daytime[(Z$PickupHour >= 0 & Z$PickupHour <= 4) | 
            Z$PickupHour >= 22] <- 0
C$Daytime[Z$PickupHour >= 6 & Z$PickupHour <= 12] <- 1
Z$Daytime <- C$Daytime
C2 <- C[C$Daytime==0 | C$Daytime==1,]
C2 <- C2[order(C2$pickup_datetime),]
#write.csv(C2, file = "pa5dat02.csv", row.names = FALSE)
######################################################
######################################################
CH0 <- C2[C2$Daytime==0,]
CH1 <- C2[C2$Daytime==1,]
## Fit kmeans per day/night 
fitH0p <- kmeans(cbind(CH0$Pickup_longitude, CH0$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH0d <- kmeans(cbind(CH0$Dropoff_longitude, CH0$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH1p <- kmeans(cbind(CH1$Pickup_longitude, CH1$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH1d <- kmeans(cbind(CH1$Dropoff_longitude, CH1$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
yy <- rbind(cbind(CH0,pClusterDaily=fitH0p$cluster,dClusterDaily=fitH0d$cluster),
            cbind(CH1,pClusterDaily=fitH1p$cluster,dClusterDaily=fitH1d$cluster))
yy <- yy[order(yy$pickup_datetime),]
######################################################
######################################################
CQ1 <- C2[C2$quarter==1,]
CQ2 <- C2[C2$quarter==2,]
CQ3 <- C2[C2$quarter==3,]
CQ4 <- C2[C2$quarter==4,]
## Fit kmeans per season 
fitQ1p <- kmeans(cbind(CQ1$Pickup_longitude, CQ1$Pickup_latitude), 
              6, nstart = 10, iter.max = 20)
fitQ1d <- kmeans(cbind(CQ1$Dropoff_longitude, CQ1$Dropoff_latitude), 
               6, nstart = 10, iter.max = 20)
fitQ2p <- kmeans(cbind(CQ2$Pickup_longitude, CQ2$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ2d <- kmeans(cbind(CQ2$Dropoff_longitude, CQ2$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ3p <- kmeans(cbind(CQ3$Pickup_longitude, CQ3$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ3d <- kmeans(cbind(CQ3$Dropoff_longitude, CQ3$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ4p <- kmeans(cbind(CQ4$Pickup_longitude, CQ4$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ4d <- kmeans(cbind(CQ4$Dropoff_longitude, CQ4$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
yy2 <- rbind(cbind(CQ1,pClusterQ=fitQ1p$cluster,dClusterQ=fitQ1d$cluster),
            cbind(CQ2,pClusterQ=fitQ2p$cluster,dClusterQ=fitQ2d$cluster), 
            cbind(CQ3,pClusterQ=fitQ3p$cluster,dClusterQ=fitQ3d$cluster), 
            cbind(CQ4,pClusterQ=fitQ4p$cluster,dClusterQ=fitQ4d$cluster))
yy2 <- yy2[order(yy2$pickup_datetime),]
######################################################
######################################################
tmp <- rbind(fit$centers,fitH0p$centers,fitH1p$centers, 
             fitQ1p$centers,fitQ2p$centers,fitQ3p$centers,
             fitQ4p$centers)
centers <- data.frame(pickup_longitute=tmp[,1],
                      pickup_latitude=tmp[,2])
centers$quarter <- rep(-1,dim(centers)[1])
centers$quarter[3*6+(1:6)] <- 1
centers$quarter[4*6+(1:6)] <- 2
centers$quarter[5*6+(1:6)] <- 3
centers$quarter[6*6+(1:6)] <- 4
centers$Daytime <- rep(-1,dim(centers)[1])
centers$Daytime[1*6+(1:6)] <- 0
centers$Daytime[2*6+(1:6)] <- 1
write.csv(centers, file = "CentersPickup.csv", row.names = FALSE)
######################################################
tmp2 <- rbind(fit2$centers,fitH0d$centers,fitH1d$centers, 
             fitQ1d$centers,fitQ2d$centers,fitQ3d$centers,
             fitQ4d$centers)
centers2 <- data.frame(dropoff_longitute=tmp2[,1],
                       dropoff_latitude=tmp2[,2])
centers2$quarter <- rep(-1,dim(centers2)[1])
centers2$quarter[3*6+(1:6)] <- 1
centers2$quarter[4*6+(1:6)] <- 2
centers2$quarter[5*6+(1:6)] <- 3
centers2$quarter[6*6+(1:6)] <- 4
centers2$Daytime <- rep(-1,dim(centers2)[1])
centers2$Daytime[1*6+(1:6)] <- 0
centers2$Daytime[2*6+(1:6)] <- 1
write.csv(centers2, file = "CentersDropoff.csv", row.names = FALSE)
######################################################
######################################################
CQ1H0 <- CQ1[CQ1$Daytime==0,]
CQ1H1 <- CQ1[CQ1$Daytime==1,]
## Fit kmeans per day/night 
fitCQ1H0p <- kmeans(cbind(CQ1H0$Pickup_longitude, CQ1H0$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitCQ1H0d <- kmeans(cbind(CQ1H0$Dropoff_longitude, CQ1H0$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
fitCQ1H1p <- kmeans(cbind(CQ1H1$Pickup_longitude, CQ1H1$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitCQ1H1d <- kmeans(cbind(CQ1H1$Dropoff_longitude, CQ1H1$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
######################################################
CQ2H0 <- CQ2[CQ2$Daytime==0,]
CQ2H1 <- CQ2[CQ2$Daytime==1,]
## Fit kmeans per day/night 
fitCQ2H0p <- kmeans(cbind(CQ2H0$Pickup_longitude, CQ2H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H0d <- kmeans(cbind(CQ2H0$Dropoff_longitude, CQ2H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H1p <- kmeans(cbind(CQ2H1$Pickup_longitude, CQ2H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H1d <- kmeans(cbind(CQ2H1$Dropoff_longitude, CQ2H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
######################################################
CQ3H0 <- CQ3[CQ3$Daytime==0,]
CQ3H1 <- CQ3[CQ3$Daytime==1,]
## Fit kmeans per day/night 
fitCQ3H0p <- kmeans(cbind(CQ3H0$Pickup_longitude, CQ3H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H0d <- kmeans(cbind(CQ3H0$Dropoff_longitude, CQ3H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H1p <- kmeans(cbind(CQ3H1$Pickup_longitude, CQ3H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H1d <- kmeans(cbind(CQ3H1$Dropoff_longitude, CQ3H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
######################################################
CQ4H0 <- CQ4[CQ4$Daytime==0,]
CQ4H1 <- CQ4[CQ4$Daytime==1,]
## Fit kmeans per day/night 
fitCQ4H0p <- kmeans(cbind(CQ4H0$Pickup_longitude, CQ4H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H0d <- kmeans(cbind(CQ4H0$Dropoff_longitude, CQ4H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H1p <- kmeans(cbind(CQ4H1$Pickup_longitude, CQ4H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H1d <- kmeans(cbind(CQ4H1$Dropoff_longitude, CQ4H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
yy3 <- rbind(cbind(CQ1H0,pClusterQD=fitCQ1H0p$cluster,dClusterQD=fitCQ1H0d$cluster), 
             cbind(CQ1H1,pClusterQD=fitCQ1H1p$cluster,dClusterQD=fitCQ1H1d$cluster), 
             cbind(CQ2H0,pClusterQD=fitCQ2H0p$cluster,dClusterQD=fitCQ2H0d$cluster), 
             cbind(CQ2H1,pClusterQD=fitCQ2H1p$cluster,dClusterQD=fitCQ2H1d$cluster), 
             cbind(CQ3H0,pClusterQD=fitCQ3H0p$cluster,dClusterQD=fitCQ3H0d$cluster), 
             cbind(CQ3H1,pClusterQD=fitCQ3H1p$cluster,dClusterQD=fitCQ3H1d$cluster), 
             cbind(CQ4H0,pClusterQD=fitCQ4H0p$cluster,dClusterQD=fitCQ4H0d$cluster), 
             cbind(CQ4H1,pClusterQD=fitCQ4H1p$cluster,dClusterQD=fitCQ4H1d$cluster))
yy3 <- yy3[order(yy3$pickup_datetime),]
yz <- cbind(yy,pClusterQ=yy2$pClusterQ,dClusterQ=yy2$dClusterQ,
            pClusterQD=yy3$pClusterQD,dClusterQD=yy3$dClusterQD)
write.csv(yz, file = "pa5dat11.csv", row.names = FALSE)
######################################################
################### EXPORT TO JSON ###################
######################################################
library(rjson)
exportJson <- toJSON(unname(split(yz, 1:nrow(yz))))
write(exportJson, "pa5dat11.json")
######################################################
######################################################
tmp <- rbind(fit$centers,fitH0p$centers,fitH1p$centers, 
             fitQ1p$centers,fitQ2p$centers,fitQ3p$centers,
             fitQ4p$centers,fitCQ1H0p$centers,fitCQ1H1p$centers,
             fitCQ2H0p$centers,fitCQ2H1p$centers,fitCQ3H0p$centers,
             fitCQ3H1p$centers,fitCQ4H0p$centers,fitCQ4H1p$centers)
centers11 <- data.frame(pickup_longitute=tmp[,1],
                      pickup_latitude=tmp[,2])
centers11$quarter <- rep(-1,dim(centers11)[1])
centers11$quarter[3*6+(1:6)] <- 1
centers11$quarter[4*6+(1:6)] <- 2
centers11$quarter[5*6+(1:6)] <- 3
centers11$quarter[6*6+(1:6)] <- 4
centers11$quarter[7*6+(1:12)] <- 1
centers11$quarter[9*6+(1:12)] <- 2
centers11$quarter[11*6+(1:12)] <- 3
centers11$quarter[13*6+(1:12)] <- 4
centers11$Daytime <- rep(-1,dim(centers11)[1])
centers11$Daytime[7*6+(1:6)] <- 0
centers11$Daytime[7*6+(7:12)] <- 1
centers11$Daytime[9*6+(1:6)] <- 0
centers11$Daytime[9*6+(7:12)] <- 1
centers11$Daytime[11*6+(1:6)] <- 0
centers11$Daytime[11*6+(7:12)] <- 1
centers11$Daytime[13*6+(1:6)] <- 0
centers11$Daytime[13*6+(7:12)] <- 1
#write.csv(centers11, file = "CentersPickup2.csv", row.names = FALSE)
######################################################
######################################################
tmp2 <- rbind(fit2$centers,fitH0d$centers,fitH1d$centers, 
             fitQ1d$centers,fitQ2d$centers,fitQ3d$centers,
             fitQ4d$centers,fitCQ1H0d$centers,fitCQ1H1d$centers,
             fitCQ2H0d$centers,fitCQ2H1d$centers,fitCQ3H0d$centers,
             fitCQ3H1d$centers,fitCQ4H0d$centers,fitCQ4H1d$centers)
centers12 <- data.frame(pickup_longitute=tmp2[,1],
                        pickup_latitude=tmp2[,2])
centers12$quarter <- rep(-1,dim(centers12)[1])
centers12$quarter[3*6+(1:6)] <- 1
centers12$quarter[4*6+(1:6)] <- 2
centers12$quarter[5*6+(1:6)] <- 3
centers12$quarter[6*6+(1:6)] <- 4
centers12$quarter[7*6+(1:12)] <- 1
centers12$quarter[9*6+(1:12)] <- 2
centers12$quarter[11*6+(1:12)] <- 3
centers12$quarter[13*6+(1:12)] <- 4
centers12$Daytime <- rep(-1,dim(centers12)[1])
centers12$Daytime[7*6+(1:6)] <- 0
centers12$Daytime[7*6+(7:12)] <- 1
centers12$Daytime[9*6+(1:6)] <- 0
centers12$Daytime[9*6+(7:12)] <- 1
centers12$Daytime[11*6+(1:6)] <- 0
centers12$Daytime[11*6+(7:12)] <- 1
centers12$Daytime[13*6+(1:6)] <- 0
centers12$Daytime[13*6+(7:12)] <- 1
#write.csv(centers12, file = "CentersDropoff2.csv", row.names = FALSE)
######################################################
######################################################
################### EXPORT TO JSON ###################
######################################################
library(rjson)
#exportJson <- toJSON(C2)
#write(exportJson, "pa5dat021.json")
#json_data <- fromJSON(file="pa5dat022.json")
#rm(exportJson)
#exportJson <- toJSON(unname(split(C2, 1:nrow(C2))))
#write(exportJson, "pa5dat022.json")
######################################################
######################################################
## --------------------------------------------------------
## Define a time interval and isolate relevant observations 
startDate = as.Date('2015-01-01',tz='GMT')
endDate = as.Date('2015-03-31',tz='GMT')
C3 <- C[as.Date(C$pickup_datetime) >= startDate & 
          as.Date(C$pickup_datetime) <= endDate, ]
## -----------------------------------------------
## Sample 1000 data points randomly, 
## within the preselected time interval 
C3 <- C[sample(nrow(C3), 1e3), ]
C3 <- C3[order(C3$pickup_datetime),]
######################################################
######################################################
######################################################
i <- 2
fitx <- kmeans(cbind(C3$Pickup_longitude, C3$Pickup_latitude), 
               6, nstart = 10, iter.max = 20)
fitx2 <- kmeans(cbind(C3$Dropoff_longitude, C3$Dropoff_latitude), 6, 
                nstart = 10, iter.max = 20)
par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(C3$Pickup_longitude, C3$Pickup_latitude, col=1, 
     type='p', main='Green Taxi Trip Count', 
     xlab='Pickup longitude', ylab='Pickup latitude')
points(C3$Pickup_longitude, C3$Pickup_latitude, 
       col=fitx$cluster)
#points(fit$centers[,1],fit$centers[,2],col=2,lwd=5,pch=3)
par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(C3$Dropoff_longitude, C3$Dropoff_latitude, col=1, 
     type='p', main='Green Taxi Trip Count', 
     xlab='Pickup longitude', ylab='Pickup latitude')
points(C3$Dropoff_longitude, C3$Dropoff_latitude, 
       col=fitx2$cluster)
#points(fit2$centers[,1],fit2$centers[,2],col=1,lwd=5,pch=3)
par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(yz$Pickup_longitude[yz$pClusterQD==2 & yz$quarter==1 & yz$Daytime==1], 
     yz$Pickup_latitude[yz$pClusterQD==2 & yz$quarter==1 & yz$Daytime==1], 
     col=1, type='p', main='Green Taxi Trip Count', 
     xlab='Pickup longitude', ylab='Pickup latitude')
points(yz$Dropoff_longitude[yz$pClusterQD==2 & yz$quarter==1 & yz$Daytime==1], 
     yz$Dropoff_latitude[yz$pClusterQD==2 & yz$quarter==1 & yz$Daytime==1], 
     col=2, type='p', main='Green Taxi Trip Count', 
     xlab='Pickup longitude', ylab='Pickup latitude')



