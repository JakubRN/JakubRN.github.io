#############################################################################
XQ2H0 <- CQ2H0[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ2H0p <- XQ2H0[XQ2H0$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ2H0d <- XQ2H0[XQ2H0$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ2H0p)
#write(exportJson, "ClusterData\\pC1Q2Night.json")
#rm(exportJson)
#exportJson <- toJSON(XQ2H0d)
#write(exportJson, "ClusterData\\dC1Q2Night.json")
ptmp <- XQ2H0p[sample(nrow(XQ2H0p), floor(0.15*dim(XQ2H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ2H0d[sample(nrow(XQ2H0d), floor(0.15*dim(XQ2H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
XQ2H1 <- CQ2H1[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ2H1p <- XQ2H1[XQ2H1$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ2H1d <- XQ2H1[XQ2H1$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ2H1p)
#write(exportJson, "ClusterData\\pC1Q2Day.json")
#rm(exportJson)
#exportJson <- toJSON(XQ2H1d)
#write(exportJson, "ClusterData\\dC1Q2Day.json")
ptmp <- XQ2H1p[sample(nrow(XQ2H1p), floor(0.15*dim(XQ2H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ2H1d[sample(nrow(XQ2H1d), floor(0.15*dim(XQ2H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q2H0 <- CQ2H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q2H0p <- X2Q2H0[X2Q2H0$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q2H0d <- X2Q2H0[X2Q2H0$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q2H0p[sample(nrow(X2Q2H0p), floor(0.15*dim(X2Q2H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q2H0d[sample(nrow(X2Q2H0d), floor(0.15*dim(X2Q2H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q2H1 <- CQ2H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q2H1p <- X2Q2H1[X2Q2H1$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q2H1d <- X2Q2H1[X2Q2H1$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q2H1p[sample(nrow(X2Q2H1p), floor(0.15*dim(X2Q2H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q2H1d[sample(nrow(X2Q2H1d), floor(0.15*dim(X2Q2H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q2H0 <- CQ2H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q2H0p <- X3Q2H0[X3Q2H0$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q2H0d <- X3Q2H0[X3Q2H0$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q2H0p[sample(nrow(X3Q2H0p), floor(0.15*dim(X3Q2H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q2H0d[sample(nrow(X3Q2H0d), floor(0.15*dim(X3Q2H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q2H1 <- CQ2H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q2H1p <- X3Q2H1[X3Q2H1$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q2H1d <- X3Q2H1[X3Q2H1$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q2H1p[sample(nrow(X3Q2H1p), floor(0.15*dim(X3Q2H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q2H1d[sample(nrow(X3Q2H1d), floor(0.15*dim(X3Q2H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q2H0 <- CQ2H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q2H0p <- X4Q2H0[X4Q2H0$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q2H0d <- X4Q2H0[X4Q2H0$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q2H0p[sample(nrow(X4Q2H0p), floor(0.15*dim(X4Q2H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q2H0d[sample(nrow(X4Q2H0d), floor(0.15*dim(X4Q2H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q2H1 <- CQ2H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q2H1p <- X4Q2H1[X4Q2H1$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q2H1d <- X4Q2H1[X4Q2H1$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q2H1p[sample(nrow(X4Q2H1p), floor(0.15*dim(X4Q2H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q2H1d[sample(nrow(X4Q2H1d), floor(0.15*dim(X4Q2H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q2H0 <- CQ2H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q2H0p <- X5Q2H0[X5Q2H0$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q2H0d <- X5Q2H0[X5Q2H0$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q2H0p[sample(nrow(X5Q2H0p), floor(0.15*dim(X5Q2H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q2H0d[sample(nrow(X5Q2H0d), floor(0.15*dim(X5Q2H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q2H1 <- CQ2H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q2H1p <- X5Q2H1[X5Q2H1$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q2H1d <- X5Q2H1[X5Q2H1$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q2H1p[sample(nrow(X5Q2H1p), floor(0.15*dim(X5Q2H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q2H1d[sample(nrow(X5Q2H1d), floor(0.15*dim(X5Q2H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q2H0 <- CQ2H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q2H0p <- X6Q2H0[X6Q2H0$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q2H0d <- X6Q2H0[X6Q2H0$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q2H0p[sample(nrow(X6Q2H0p), floor(0.15*dim(X6Q2H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q2H0d[sample(nrow(X6Q2H0d), floor(0.15*dim(X6Q2H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q2H1 <- CQ2H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q2H1p <- X6Q2H1[X6Q2H1$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q2H1d <- X6Q2H1[X6Q2H1$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q2H1p[sample(nrow(X6Q2H1p), floor(0.15*dim(X6Q2H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q2H1d[sample(nrow(X6Q2H1d), floor(0.15*dim(X6Q2H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
