# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
## --------------
library(rjson)
## Read data file 
C <- read.csv("pa5dat01.csv", sep=',', head=TRUE)
## --------------------------------------------------------
## Change datetime format to enable mathematical operations
C$pickup_datetime <- as.POSIXct(C$pickup_datetime,tz='GMT')
C$dropoff_datetime <- as.POSIXct(C$dropoff_datetime,tz='GMT')
## ----------------------------------------------------------
############################################
############### FULL DATASET ###############
############################################
## Fit kmeans to both pickup and dropoff locations 
fit <- kmeans(cbind(C$Pickup_longitude, C$Pickup_latitude), 
              6, nstart = 10, iter.max = 20)
fit2 <- kmeans(cbind(C$Dropoff_longitude, C$Dropoff_latitude), 
               6, nstart = 10, iter.max = 20)
#write.csv(fit$centers, file = "ClusterCenters\\pCenters.csv", row.names = FALSE)
#write.csv(fit2$centers, file = "ClusterCenters\\dCenters.csv", row.names = FALSE)
C$pCluster <- rep(0,1.2e6)
C$pCluster <- fit$cluster
C$dCluster <- rep(0,1.2e6)
C$dCluster <- fit2$cluster
## Add a column to indicate each quarter  
C$quarter <- rep(0,1.2e6)
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-01-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-03-31',tz='GMT')] <- 1
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-04-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-06-30',tz='GMT')] <- 2
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-07-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-09-30',tz='GMT')] <- 3
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-10-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-12-31',tz='GMT')] <- 4
## Add a column to separate between two time zones 
## Morning time - 22PM to 4AM, Night time - 6AM to 12PM 
require(lubridate)
Z <- data.frame(PickupHour=hour(C$pickup_datetime), 
                PickupDay=day(C$pickup_datetime), 
                PickupMonth=month(C$pickup_datetime), 
                DropoffHour=hour(C$dropoff_datetime), 
                DropoffDay=day(C$dropoff_datetime), 
                DropoffMonth=month(C$dropoff_datetime), 
                Quarter=C$quarter)
C$Daytime <- rep(-1,1.2e6)
C$Daytime[(Z$PickupHour >= 0 & Z$PickupHour <= 4) | 
            Z$PickupHour >= 22] <- 0
C$Daytime[Z$PickupHour >= 6 & Z$PickupHour <= 12] <- 1
Z$Daytime <- C$Daytime
C2 <- C[C$Daytime==0 | C$Daytime==1,]
C2 <- C2[order(C2$pickup_datetime),]
#write.csv(C2, file = "pa5dat02.csv", row.names = FALSE)
################################################################################
################################################################################
########################################
############### TIMEZONE ###############
########################################
## Night time - 22PM to 4AM 
CH0 <- C2[C2$Daytime==0,]
## Fit kmeans to Night trips 
fitH0p <- kmeans(cbind(CH0$Pickup_longitude, CH0$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH0d <- kmeans(cbind(CH0$Dropoff_longitude, CH0$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(CH0$Pickup_longitude, CH0$Pickup_latitude, col=1, 
     type='p', main='Green Taxi Trip Count', 
     xlab='Pickup longitude', ylab='Pickup latitude')
points(fitH0p$centers[,1],fitH0p$centers[,2],col=2,lwd=4)
points(fitH0d$centers[,1],fitH0d$centers[,2],col=3,lwd=4)
#abline(h=40.2,col=2)
#abline(h=41.25,col=2)
#abline(v=-75.5,col=2)
#abline(v=-72.5,col=2)
#write.csv(fitH0p$centers, file = "ClusterCenters\\pCentersNight.csv", row.names = FALSE)
#write.csv(fitH0d$centers, file = "ClusterCenters\\dCentersNight.csv", row.names = FALSE)
H0 <- CH0[,c("Pickup_longitude","Pickup_latitude",
             "Dropoff_longitude","Dropoff_latitude",
             "pCluster","dCluster")]
H01p <- H0[H0$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                            "Dropoff_longitude","Dropoff_latitude",
                            "dCluster")]
#write.csv(H01p, file = "ClusterData\\pNightC1.csv", row.names = FALSE)
#rm(exportJson)
#exportJson <- toJSON(H01p)
#write(exportJson, "ClusterData\\pNightC1.json")
H01d <- H0[H0$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                            "Dropoff_longitude","Dropoff_latitude",
                            "pCluster")]
#write.csv(H01d, file = "ClusterData\\dNightC1.csv", row.names = FALSE)
#rm(exportJson)
#exportJson <- toJSON(H01d)
#write(exportJson, "ClusterData\\dNightC1.json")
## Day time - 6AM to 12PM 
CH1 <- C2[C2$Daytime==1,]
## Fit kmeans to Day trips 
fitH1p <- kmeans(cbind(CH1$Pickup_longitude, CH1$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH1d <- kmeans(cbind(CH1$Dropoff_longitude, CH1$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
#write.csv(fitH1p$centers, file = "ClusterCenters\\pCentersDay.csv", row.names = FALSE)
#write.csv(fitH1d$centers, file = "ClusterCenters\\dCentersDay.csv", row.names = FALSE)
########################################
############### QUARTERS ###############
########################################
CQ1 <- C2[C2$quarter==1,]
## Fit kmeans to the first quarter trips 
fitQ1p <- kmeans(cbind(CQ1$Pickup_longitude, CQ1$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ1d <- kmeans(cbind(CQ1$Dropoff_longitude, CQ1$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
#write.csv(fitQ1p$centers, file = "ClusterCenters\\pCentersQ1.csv", row.names = FALSE)
#write.csv(fitQ1d$centers, file = "ClusterCenters\\dCentersQ1.csv", row.names = FALSE)
CQ2 <- C2[C2$quarter==2,]
## Fit kmeans to the second quarter trips 
fitQ2p <- kmeans(cbind(CQ2$Pickup_longitude, CQ2$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ2d <- kmeans(cbind(CQ2$Dropoff_longitude, CQ2$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
#write.csv(fitQ2p$centers, file = "ClusterCenters\\pCentersQ2.csv", row.names = FALSE)
#write.csv(fitQ2d$centers, file = "ClusterCenters\\dCentersQ2.csv", row.names = FALSE)
CQ3 <- C2[C2$quarter==3,]
## Fit kmeans to the third quarter trips 
fitQ3p <- kmeans(cbind(CQ3$Pickup_longitude, CQ3$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ3d <- kmeans(cbind(CQ3$Dropoff_longitude, CQ3$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
#write.csv(fitQ3p$centers, file = "ClusterCenters\\pCentersQ3.csv", row.names = FALSE)
#write.csv(fitQ3d$centers, file = "ClusterCenters\\dCentersQ3.csv", row.names = FALSE)
CQ4 <- C2[C2$quarter==4,]
## Fit kmeans to the fourth quarter trips 
fitQ4p <- kmeans(cbind(CQ4$Pickup_longitude, CQ4$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ4d <- kmeans(cbind(CQ4$Dropoff_longitude, CQ4$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)
#write.csv(fitQ4p$centers, file = "ClusterCenters\\pCentersQ4.csv", row.names = FALSE)
#write.csv(fitQ4d$centers, file = "ClusterCenters\\dCentersQ4.csv", row.names = FALSE)
#####################################################
############### QUARTERS AND TIMEZONE ###############
#####################################################
CQ1H0 <- CQ1[CQ1$Daytime==0,]
## Fit kmeans to the first quarter night trips 
fitCQ1H0p <- kmeans(cbind(CQ1H0$Pickup_longitude, CQ1H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ1H0d <- kmeans(cbind(CQ1H0$Dropoff_longitude, CQ1H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ1H0p$centers, file = "ClusterCenters\\pCentersCQ1Night.csv", row.names = FALSE)
#write.csv(fitCQ1H0d$centers, file = "ClusterCenters\\dCentersCQ1Night.csv", row.names = FALSE)
CQ1H1 <- CQ1[CQ1$Daytime==1,]
## Fit kmeans to the first quarter day trips 
fitCQ1H1p <- kmeans(cbind(CQ1H1$Pickup_longitude, CQ1H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ1H1d <- kmeans(cbind(CQ1H1$Dropoff_longitude, CQ1H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ1H1p$centers, file = "ClusterCenters\\pCentersCQ1Day.csv", row.names = FALSE)
#write.csv(fitCQ1H1d$centers, file = "ClusterCenters\\dCentersCQ1Day.csv", row.names = FALSE)
CQ2H0 <- CQ2[CQ2$Daytime==0,]
## Fit kmeans to the second quarter night trips 
fitCQ2H0p <- kmeans(cbind(CQ2H0$Pickup_longitude, CQ2H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H0d <- kmeans(cbind(CQ2H0$Dropoff_longitude, CQ2H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ2H0p$centers, file = "ClusterCenters\\pCentersCQ2Night.csv", row.names = FALSE)
#write.csv(fitCQ2H0d$centers, file = "ClusterCenters\\dCentersCQ2Night.csv", row.names = FALSE)
CQ2H1 <- CQ2[CQ2$Daytime==1,]
## Fit kmeans to the second quarter day trips 
fitCQ2H1p <- kmeans(cbind(CQ2H1$Pickup_longitude, CQ2H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H1d <- kmeans(cbind(CQ2H1$Dropoff_longitude, CQ2H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ2H1p$centers, file = "ClusterCenters\\pCentersCQ2Day.csv", row.names = FALSE)
#write.csv(fitCQ2H1d$centers, file = "ClusterCenters\\dCentersCQ2Day.csv", row.names = FALSE)
CQ3H0 <- CQ3[CQ3$Daytime==0,]
## Fit kmeans to the third quarter day trips 
fitCQ3H0p <- kmeans(cbind(CQ3H0$Pickup_longitude, CQ3H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H0d <- kmeans(cbind(CQ3H0$Dropoff_longitude, CQ3H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ3H0p$centers, file = "ClusterCenters\\pCentersCQ3Night.csv", row.names = FALSE)
#write.csv(fitCQ3H0d$centers, file = "ClusterCenters\\dCentersCQ3Night.csv", row.names = FALSE)
CQ3H1 <- CQ3[CQ3$Daytime==1,]
## Fit kmeans to the third quarter day trips 
fitCQ3H1p <- kmeans(cbind(CQ3H1$Pickup_longitude, CQ3H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H1d <- kmeans(cbind(CQ3H1$Dropoff_longitude, CQ3H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ3H1p$centers, file = "ClusterCenters\\pCentersCQ3Day.csv", row.names = FALSE)
#write.csv(fitCQ3H1d$centers, file = "ClusterCenters\\dCentersCQ3Day.csv", row.names = FALSE)
CQ4H0 <- CQ4[CQ4$Daytime==0,]
## Fit kmeans to the fourth quarter day trips 
fitCQ4H0p <- kmeans(cbind(CQ4H0$Pickup_longitude, CQ4H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H0d <- kmeans(cbind(CQ4H0$Dropoff_longitude, CQ4H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ4H0p$centers, file = "ClusterCenters\\pCentersCQ4Night.csv", row.names = FALSE)
#write.csv(fitCQ4H0d$centers, file = "ClusterCenters\\dCentersCQ4Night.csv", row.names = FALSE)
CQ4H1 <- CQ4[CQ4$Daytime==1,]
## Fit kmeans to the fourth quarter day trips 
fitCQ4H1p <- kmeans(cbind(CQ4H1$Pickup_longitude, CQ4H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H1d <- kmeans(cbind(CQ4H1$Dropoff_longitude, CQ4H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)
#write.csv(fitCQ4H1p$centers, file = "ClusterCenters\\pCentersCQ4Day.csv", row.names = FALSE)
#write.csv(fitCQ4H1d$centers, file = "ClusterCenters\\dCentersCQ4Day.csv", row.names = FALSE)
XQ1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
             "Dropoff_longitude","Dropoff_latitude",
             "pCluster","dCluster")]
XQ1H0p <- XQ1H0[XQ1H0$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                            "Dropoff_longitude","Dropoff_latitude",
                            "dCluster")]
XQ1H0d <- XQ1H0[XQ1H0$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ1H0p)
#write(exportJson, "ClusterData\\pC1Q1Night.json")
#rm(exportJson)
#exportJson <- toJSON(XQ1H0d)
#write(exportJson, "ClusterData\\dC1Q1Night.json")
XQ1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ1H1p <- XQ1H0[XQ1H1$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ1H1d <- XQ1H0[XQ1H1$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ1H1p)
#write(exportJson, "ClusterData\\pC1Q1Day.json")
#rm(exportJson)
#exportJson <- toJSON(XQ1H1d)
#write(exportJson, "ClusterData\\dC1Q1Day.json")
X2Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
X2Q1H0p <- X2Q1H0[X2Q1H0$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
X2Q1H0d <- X2Q1H0[X2Q1H0$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
rm(exportJson)
exportJson <- toJSON(X2Q1H0p)
write(exportJson, "ClusterData\\pC2Q1Night.json")
rm(exportJson)
exportJson <- toJSON(X2Q1H0d)
write(exportJson, "ClusterData\\dC2Q1Night.json")
X2Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q1H1p <- X2Q1H1[X2Q1H1$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                     "Dropoff_longitude","Dropoff_latitude",
                                     "dCluster")]
X2Q1H1d <- X2Q1H1[X2Q1H1$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                     "Dropoff_longitude","Dropoff_latitude",
                                     "pCluster")]
rm(exportJson)
exportJson <- toJSON(X2Q1H1p)
write(exportJson, "ClusterData\\pC2Q1Day.json")
rm(exportJson)
exportJson <- toJSON(X2Q1H1d)
write(exportJson, "ClusterData\\dC2Q1Day.json")
#############################################################################
X3Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q1H0p <- X3Q1H0[X3Q1H0$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q1H0d <- X3Q1H0[X3Q1H0$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X3Q1H0p)
write(exportJson, "ClusterData\\pC3Q1Night.json")
rm(exportJson)
exportJson <- toJSON(X3Q1H0d)
write(exportJson, "ClusterData\\dC3Q1Night.json")
X3Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q1H1p <- X3Q1H1[X3Q1H1$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q1H1d <- X3Q1H1[X3Q1H1$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X3Q1H1p)
write(exportJson, "ClusterData\\pC3Q1Day.json")
rm(exportJson)
exportJson <- toJSON(X3Q1H1d)
write(exportJson, "ClusterData\\dC3Q1Day.json")
#############################################################################
X4Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q1H0p <- X4Q1H0[X4Q1H0$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q1H0d <- X4Q1H0[X4Q1H0$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X4Q1H0p)
write(exportJson, "ClusterData\\pC4Q1Night.json")
rm(exportJson)
exportJson <- toJSON(X4Q1H0d)
write(exportJson, "ClusterData\\dC4Q1Night.json")
X4Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q1H1p <- X4Q1H1[X4Q1H1$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q1H1d <- X4Q1H1[X4Q1H1$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X4Q1H1p)
write(exportJson, "ClusterData\\pC4Q1Day.json")
rm(exportJson)
exportJson <- toJSON(X4Q1H1d)
write(exportJson, "ClusterData\\dC4Q1Day.json")
#############################################################################
X5Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q1H0p <- X5Q1H0[X5Q1H0$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q1H0d <- X5Q1H0[X5Q1H0$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X5Q1H0p)
write(exportJson, "ClusterData\\pC5Q1Night.json")
rm(exportJson)
exportJson <- toJSON(X5Q1H0d)
write(exportJson, "ClusterData\\dC5Q1Night.json")
X5Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q1H1p <- X5Q1H1[X5Q1H1$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q1H1d <- X5Q1H1[X5Q1H1$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X5Q1H1p)
write(exportJson, "ClusterData\\pC5Q1Day.json")
rm(exportJson)
exportJson <- toJSON(X5Q1H1d)
write(exportJson, "ClusterData\\dC5Q1Day.json")
#############################################################################
X6Q1H0 <- CQ1H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q1H0p <- X6Q1H0[X6Q1H0$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q1H0d <- X6Q1H0[X6Q1H0$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X6Q1H0p)
write(exportJson, "ClusterData\\pC6Q1Night.json")
rm(exportJson)
exportJson <- toJSON(X6Q1H0d)
write(exportJson, "ClusterData\\dC6Q1Night.json")
X6Q1H1 <- CQ1H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q1H1p <- X6Q1H1[X6Q1H1$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q1H1d <- X6Q1H1[X6Q1H1$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
rm(exportJson)
exportJson <- toJSON(X6Q1H1p)
write(exportJson, "ClusterData\\pC6Q1Day.json")
rm(exportJson)
exportJson <- toJSON(X6Q1H1d)
write(exportJson, "ClusterData\\dC6Q1Day.json")
#############################################################################
#############################################################################



