import pandas as pd
import glob
import json
#from datetime import datetime
from collections import defaultdict
import sys
import os
def rec_dd():
    return defaultdict(rec_dd)

def readData(file):
    df = pd.read_csv(file, dtype={'pCluster':float, 'dCluster':float, 'Count':float})
    ds = df.to_dict('records')
    return ds

dict = rec_dd()

for file in glob.glob('Connections/*.csv'):
    result = os.path.basename(file).split('.')[0]
    result2 = ''.join(result.split('Data'))
    if(result2[0:3] == 'all'):
        if(len(result2) == 3):
            dict['Connections'] = readData(file)
        else:
            dict[result2[3:]]['Connections'] = readData(file)
    else:
        dict[result2[0:2]][result2[2:]]['Connections'] = readData(file)




with open('Connections.json', 'w') as f:
    json.dump(dict, f)
sys.exit(0)
