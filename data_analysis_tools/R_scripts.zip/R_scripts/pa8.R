# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
##############################################################
colourmap <- read.csv("colourmap.csv", sep=',', head=TRUE)
colourmap$hue <- rep(0,5)
for(i in 1:5) {
  colourmap$hue[i] <- colourmap$persons_per_km2[i]/sum(colourmap$persons_per_km2)
}
colourmap$hue <- round(colourmap$hue/max(colourmap$hue),2)
write.csv(colourmap,"colourmap2.csv", row.names = FALSE)
##############################################################
##############################################################
##############################################################
xx <- read.csv("Connections\\allData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allData.csv", row.names = FALSE)

xx <- read.csv("Connections\\allDayData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allDayData.csv", row.names = FALSE)

xx <- read.csv("Connections\\allNightData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allNightData.csv", row.names = FALSE)

xx <- read.csv("Connections\\allQ1Data.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allQ1Data.csv", row.names = FALSE)

xx <- read.csv("Connections\\allQ2Data.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allQ2Data.csv", row.names = FALSE)

xx <- read.csv("Connections\\allQ3Data.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allQ3Data.csv", row.names = FALSE)

xx <- read.csv("Connections\\allQ4Data.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\allQ4Data.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q1DayData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q1DayData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q2DayData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q2DayData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q3DayData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q3DayData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q4DayData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q4DayData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q1NightData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q1NightData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q2NightData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q2NightData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q3NightData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q3NightData.csv", row.names = FALSE)

xx <- read.csv("Connections\\Q4NightData.csv", sep=',', head=TRUE)
portions <- data.frame(pickup=rep(0,6),dropoff=rep(0,6))
for(i in 1:6) {
  portions$pickup[i] <- round(sum(xx$Count[xx$pCluster==i])/sum(xx$Count),2)
  portions$dropoff[i] <- round(sum(xx$Count[xx$dCluster==i])/sum(xx$Count),2)
}
write.csv(portions,"Portions\\Q4NightData.csv", row.names = FALSE)

######################################################################
######################################################################
######################################################################
## Read data file 
CQ1p <- read.csv("ClusterCenters\\pCentersQ1.csv", sep=',', head=TRUE)
CQ1d <- read.csv("ClusterCenters\\dCentersQ1.csv", sep=',', head=TRUE)

temp <- read.csv("Connections\\alldata.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allData.csv", row.names = FALSE)

temp <- read.csv("Connections\\allDayData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allDayData.csv", row.names = FALSE)

temp <- read.csv("Connections\\allNightData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allNightData.csv", row.names = FALSE)

temp <- read.csv("Connections\\allQ1Data.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allQ1Data.csv", row.names = FALSE)

temp <- read.csv("Connections\\allQ2Data.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allQ2Data.csv", row.names = FALSE)

temp <- read.csv("Connections\\allQ3Data.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allQ3Data.csv", row.names = FALSE)

temp <- read.csv("Connections\\allQ4Data.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\allQ4Data.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q1DayData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q1DayData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q2DayData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q2DayData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q3DayData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q3DayData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q4DayData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q4DayData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q1NightData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q1NightData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q2NightData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q2NightData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q3NightData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q3NightData.csv", row.names = FALSE)

temp <- read.csv("Connections\\Q4NightData.csv", sep=',', head=TRUE)
temp <- temp[,c(1,4,3)]
colnames(temp)[colnames(temp)=="d_old"] <- "dCluster"
temp <- temp[order(temp$dCluster, decreasing = FALSE),]
( temp <- temp[order(temp$pCluster, decreasing = FALSE),] )
#write.csv(temp, file = "C:\\Users\\George\\Google Drive\\socialDataAnalysis\\ProjectAssignment\\Connections\\Q4NightData.csv", row.names = FALSE)


minx <- min(min(CQ1p$Pickup_longitude),min(CQ1d$Dropoff_longitude))
maxx <- max(max(CQ1p$Pickup_longitude),max(CQ1d$Dropoff_longitude))
miny <- min(min(CQ1p$Pickup_latitude),min(CQ1d$Dropoff_latitude))
maxy <- max(max(CQ1p$Pickup_latitude),max(CQ1d$Dropoff_latitude))

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(CQ1p$Pickup_longitude,CQ1p$Pickup_latitude, 
     col=1,lwd=4, 
     xlim=c(minx,maxx),ylim=c(miny,maxy),
     pch = c("1","2","3","4","5","6"),
     type='p', main='Q1 Data', 
     xlab='Pickup longitude', ylab='Pickup latitude')
points(CQ1d$Dropoff_longitude,CQ1d$Dropoff_latitude,
       pch = c("1","2","3","4","5","6"),col=2)
i <- 6
j <- temp$dCluster[which.max(temp$Count[temp$pCluster==i])]
segments(CQ1p$Pickup_longitude[i],CQ1p$Pickup_latitude[i],
       CQ1d$Dropoff_longitude[j],CQ1d$Dropoff_latitude[j],
       col=2)
