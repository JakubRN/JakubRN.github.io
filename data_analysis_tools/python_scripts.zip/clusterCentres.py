import pandas as pd
# import numpy as np
import glob
import json
#from datetime import datetime
from collections import defaultdict
import sys
import os
def rec_dd():
    return defaultdict(rec_dd)

def readData(file):
    df = pd.read_csv(file)
    ds = df.to_dict('records')
    return ds

def readPortions(file):
    df = pd.read_csv(file)
    ds = df.to_dict('list')
    return ds

dict = rec_dd()
for file in glob.glob('ClusterCenters/*.csv'):
    result = os.path.basename(file).split('.')[0]
    result2 = ''.join(result.split('Centers'))
    if(len(result2) == 1):
        dict[result2[0]]['clusterData'] = readData(file)
    elif(len(result2) == 3):
        dict[result2[0]][result2[1:]]['clusterData'] = readData(file)
    elif(len(result2) == 4):
        dict[result2[0]][result2[1:]]['clusterData'] = readData(file)
    elif(len(result2) == 6):
        dict[result2[0]][result2[1:]]['clusterData'] = readData(file)
    elif(len(result2) == 7):
        dict[result2[0]][result2[2:4]][result2[4:]]['clusterData'] = readData(file)
    elif(len(result2) == 9):
        dict[result2[0]][result2[2:4]][result2[4:]]['clusterData'] = readData(file)

portions = {}
for file in glob.glob('Portions/*.csv'):
    result = os.path.basename(file).split('.')[0]
    result2 = ''.join(result.split('Data'))
    portions = readPortions(file)
    print(portions)
    if(result2[0:3] == 'all'):
        if(len(result2) == 3):
            dict['p']['Portions'] = portions['p']
            dict['d']['Portions'] = portions['d']
        else:
            dict['p'][result2[3:]]['Portions'] = portions['p']
            dict['d'][result2[3:]]['Portions'] = portions['d']
    else:
        dict['p'][result2[0:2]][result2[2:]]['Portions'] = portions['p']
        dict['d'][result2[0:2]][result2[2:]]['Portions'] = portions['d']


with open('onlyCenters.json', 'w') as f:
    json.dump(dict, f,)
sys.exit(0)
