# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
#library(rjson)
require(lubridate)

## New York City margins 
lon_min <- -74.26
lat_min <- 40.496
lon_max <- -73.7
lat_max <- 40.915

## Read data file 
C <- read.csv("pa5dat01.csv", sep=',', head=TRUE)

## Change datetime format to enable mathematical operations 
C$pickup_datetime <- as.POSIXct(C$pickup_datetime,tz='GMT')
C$dropoff_datetime <- as.POSIXct(C$dropoff_datetime,tz='GMT')

## Pickup points out of NYC 
C <- C[(C$Pickup_longitude >= lon_min & C$Pickup_longitude <= lon_max) 
       | (C$Pickup_latitude >= lat_min & C$Pickup_latitude <= lat_max),]
( count1 <- 1200000 - 1199973 )

## Dropoff points out of NYC 
C <- C[(C$Dropoff_longitude >= lon_min & C$Dropoff_longitude <= lon_max) 
       | (C$Dropoff_latitude >= lat_min & C$Dropoff_latitude <= lat_max),]
( count2 <- 1199973 - 1199932 )

#par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
#plot(C$Pickup_longitude,C$Pickup_latitude, col=1, 
#     type='p', main='All Data', 
#     xlab='Pickup longitude', ylab='Pickup latitude')

############################################
############### FULL DATASET ###############
############################################

## Fit kmeans to both pickup and dropoff locations 
fit <- kmeans(cbind(C$Pickup_longitude, C$Pickup_latitude), 
              6, nstart = 10, iter.max = 20)
fit2 <- kmeans(cbind(C$Dropoff_longitude, C$Dropoff_latitude), 
               6, nstart = 10, iter.max = 20)

ptmp <- data.frame(Pickup_longitude=fit$centers[,1],Pickup_latitude=fit$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fit2$centers[,1],Dropoff_latitude=fit2$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCenters.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCenters.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fit$centers[,1],fit$centers[,2], col=2, lwd=4, 
     pch = c("1","2","3","4","5","6"), 
     type='p', main='All Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fit2$centers[,1],fit2$centers[,2],
       pch = c("1","2","3","4","5","6"),
       col=3,lwd=4)

CC <- data.frame(pickup = fit$cluster, dropoff = fit2$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}
## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------
write.csv(CZ, file = "Connections\\allData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

## Add a column to indicate the cluster id 
#C$pCluster <- rep(0,dim(C)[1])
#C$pCluster <- fit$cluster
#C$dCluster <- rep(0,dim(C)[1])
#C$dCluster <- fit2$cluster

## Add a column to indicate each quarter  
C$quarter <- rep(0,dim(C)[1])
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-01-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-03-31',tz='GMT')] <- 1
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-04-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-06-30',tz='GMT')] <- 2
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-07-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-09-30',tz='GMT')] <- 3
C$quarter[as.Date(C$pickup_datetime) >= as.Date('2015-10-01',tz='GMT') & 
            as.Date(C$pickup_datetime) <= as.Date('2015-12-31',tz='GMT')] <- 4

## Add a column to separate between two time zones 
## Morning time - 22PM to 4AM, Night time - 6AM to 12PM 
Z <- data.frame(PickupHour=hour(C$pickup_datetime), 
                PickupDay=day(C$pickup_datetime), 
                PickupMonth=month(C$pickup_datetime), 
                DropoffHour=hour(C$dropoff_datetime), 
                DropoffDay=day(C$dropoff_datetime), 
                DropoffMonth=month(C$dropoff_datetime), 
                Quarter=C$quarter)

C$Daytime <- rep(-1,dim(C)[1])
C$Daytime[(Z$PickupHour >= 0 & Z$PickupHour <= 4) | 
            Z$PickupHour >= 22] <- 0
C$Daytime[Z$PickupHour >= 6 & Z$PickupHour <= 12] <- 1

C2 <- C[C$Daytime==0 | C$Daytime==1,]
C2 <- C2[order(C2$pickup_datetime),]
write.csv(C2, file = "pa5dat02.csv", row.names = FALSE)
########################################
############### TIMEZONE ###############
########################################

## Night time - 22PM to 4AM 
CH0 <- C2[C2$Daytime==0,]

## Fit kmeans to Night trips 
fitH0p <- kmeans(cbind(CH0$Pickup_longitude, CH0$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH0d <- kmeans(cbind(CH0$Dropoff_longitude, CH0$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)

ptmp <- data.frame(Pickup_longitude=fitH0p$centers[,1],Pickup_latitude=fitH0p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitH0d$centers[,1],Dropoff_latitude=fitH0d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersNight.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersNight.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CC <- data.frame(pickup = fitH0p$cluster, dropoff = fitH0d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\allNightData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitH0p$centers[,1],fitH0p$centers[,2], col=2, lwd=4, 
     pch = c("1","2","3","4","5","6"),
     type='p', main='Night Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitH0d$centers[,1],fitH0d$centers[,2],
       pch = c("1","2","3","4","5","6"),
       col=3,lwd=4)

#######################################################################

## Day time - 6AM to 12PM 
CH1 <- C2[C2$Daytime==1,]

## Fit kmeans to Day trips 
fitH1p <- kmeans(cbind(CH1$Pickup_longitude, CH1$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitH1d <- kmeans(cbind(CH1$Dropoff_longitude, CH1$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 200, algorithm = "MacQueen")

CC <- data.frame(pickup = fitH1p$cluster, dropoff = fitH1d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\allDayData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitH1p$centers[,1],fitH1p$centers[,2], col=2, lwd=4, 
     #pch = c("1","2","3","4","5","6"),
     type='p', main='Day and Night pickup clusters\' centers', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitH0p$centers[,1],fitH0p$centers[,2],
       #pch = c("1","2","3","4","5","6"),
       col=4,lwd=4)
legend("topleft", inset=.02, c("Day", "Night"), 
       horiz=FALSE, col=c(2,4), pch=c(1,1), 
       lty=c(NA,NA), lwd=c(4,4), cex=0.8)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitH1d$centers[,1],fitH1d$centers[,2], col=2, lwd=4, 
     #pch = c("1","2","3","4","5","6"),
     type='p', main='Day and Night dropoff clusters\' centers', 
     xlab='Dropoff longitude', ylab='Dropoff latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitH0d$centers[,1],fitH0d$centers[,2],
       #pch = c("1","2","3","4","5","6"),
       col=4,lwd=4)
legend("topleft", inset=.02, c("Day", "Night"), 
       horiz=FALSE, col=c(2,4), pch=c(1,1), 
       lty=c(NA,NA), lwd=c(4,4), cex=0.8)

ptmp <- data.frame(Pickup_longitude=fitH1p$centers[,1],Pickup_latitude=fitH1p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitH1d$centers[,1],Dropoff_latitude=fitH1d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersDay.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersDay.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

########################################
############### QUARTERS ###############
########################################

CQ1 <- C2[C2$quarter==1,]
## Fit kmeans to the first quarter trips 
fitQ1p <- kmeans(cbind(CQ1$Pickup_longitude, CQ1$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ1d <- kmeans(cbind(CQ1$Dropoff_longitude, CQ1$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitQ1p$cluster, dropoff = fitQ1d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\allQ1Data.csv", row.names = FALSE)
rm(CC)
rm(CZ)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitQ1p$centers[,1],fitQ1p$centers[,2], col=2, lwd=4, 
     type='p', main='Q1 Data', 
     pch = c("1","2","3","4","5","6"),
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitQ1d$centers[,1],fitQ1d$centers[,2],
       pch = c("1","2","3","4","5","6"),
       col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitQ1p$centers[,1],Pickup_latitude=fitQ1p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitQ1d$centers[,1],Dropoff_latitude=fitQ1d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersQ1.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersQ1.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ2 <- C2[C2$quarter==2,]
## Fit kmeans to the second quarter trips 
fitQ2p <- kmeans(cbind(CQ2$Pickup_longitude, CQ2$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ2d <- kmeans(cbind(CQ2$Dropoff_longitude, CQ2$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitQ2p$cluster, dropoff = fitQ2d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\allQ2Data.csv", row.names = FALSE)
rm(CC)
rm(CZ)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitQ2p$centers[,1],fitQ2p$centers[,2], col=2, lwd=4, 
     type='p', main='Q2 Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitQ2d$centers[,1],fitQ2d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitQ2p$centers[,1],Pickup_latitude=fitQ2p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitQ2d$centers[,1],Dropoff_latitude=fitQ2d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersQ2.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersQ2.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ3 <- C2[C2$quarter==3,]
## Fit kmeans to the third quarter trips 
fitQ3p <- kmeans(cbind(CQ3$Pickup_longitude, CQ3$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ3d <- kmeans(cbind(CQ3$Dropoff_longitude, CQ3$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitQ3p$cluster, dropoff = fitQ3d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\allQ3Data.csv", row.names = FALSE)
rm(CC)
rm(CZ)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitQ3p$centers[,1],fitQ3p$centers[,2], col=2, lwd=4, 
     type='p', main='Q3 Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitQ3d$centers[,1],fitQ3d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitQ3p$centers[,1],Pickup_latitude=fitQ3p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitQ3d$centers[,1],Dropoff_latitude=fitQ3d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersQ3.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersQ3.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ4 <- C2[C2$quarter==4,]
## Fit kmeans to the fourth quarter trips 
fitQ4p <- kmeans(cbind(CQ4$Pickup_longitude, CQ4$Pickup_latitude), 
                 6, nstart = 10, iter.max = 20)
fitQ4d <- kmeans(cbind(CQ4$Dropoff_longitude, CQ4$Dropoff_latitude), 
                 6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitQ4p$cluster, dropoff = fitQ4d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\allQ4Data.csv", row.names = FALSE)
rm(CC)
rm(CZ)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitQ4p$centers[,1],fitQ4p$centers[,2], col=2, lwd=4, 
     type='p', main='Q4 Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitQ4d$centers[,1],fitQ4d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitQ4p$centers[,1],Pickup_latitude=fitQ4p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitQ4d$centers[,1],Dropoff_latitude=fitQ4d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersQ4.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersQ4.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

#####################################################
############### QUARTERS AND TIMEZONE ###############
#####################################################

CQ1H0 <- CQ1[CQ1$Daytime==0,]
## Fit kmeans to the first quarter night trips 
fitCQ1H0p <- kmeans(cbind(CQ1H0$Pickup_longitude, CQ1H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ1H0d <- kmeans(cbind(CQ1H0$Dropoff_longitude, CQ1H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ1H0p$cluster, dropoff = fitCQ1H0d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q1NightData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ1H0$pCluster <- fitCQ1H0p$cluster
CQ1H0$dCluster <- fitCQ1H0d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ1H0p$centers[,1],fitCQ1H0p$centers[,2], col=2, lwd=4, 
     type='p', main='Q1 Night Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ1H0d$centers[,1],fitCQ1H0d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ1H0p$centers[,1],Pickup_latitude=fitCQ1H0p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ1H0d$centers[,1],Dropoff_latitude=fitCQ1H0d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ1Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ1Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ1H1 <- CQ1[CQ1$Daytime==1,]
## Fit kmeans to the first quarter day trips 
fitCQ1H1p <- kmeans(cbind(CQ1H1$Pickup_longitude, CQ1H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ1H1d <- kmeans(cbind(CQ1H1$Dropoff_longitude, CQ1H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ1H1p$cluster, dropoff = fitCQ1H1d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q1DayData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ1H1$pCluster <- fitCQ1H1p$cluster
CQ1H1$dCluster <- fitCQ1H1d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ1H1p$centers[,1],fitCQ1H1p$centers[,2], col=2, lwd=4, 
     type='p', main='Q1 Day Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ1H1d$centers[,1],fitCQ1H1d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ1H1p$centers[,1],Pickup_latitude=fitCQ1H1p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ1H1d$centers[,1],Dropoff_latitude=fitCQ1H1d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ1Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ1Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ2H0 <- CQ2[CQ2$Daytime==0,]
## Fit kmeans to the second quarter night trips 
fitCQ2H0p <- kmeans(cbind(CQ2H0$Pickup_longitude, CQ2H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H0d <- kmeans(cbind(CQ2H0$Dropoff_longitude, CQ2H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ2H0p$cluster, dropoff = fitCQ2H0d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q2NightData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ2H0$pCluster <- fitCQ2H0p$cluster
CQ2H0$dCluster <- fitCQ2H0d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ2H0p$centers[,1],fitCQ2H0p$centers[,2], col=2, lwd=4, 
     type='p', main='Q1 Night Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ2H0d$centers[,1],fitCQ2H0d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ2H0p$centers[,1],Pickup_latitude=fitCQ2H0p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ2H0d$centers[,1],Dropoff_latitude=fitCQ2H0d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ2Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ2Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ2H1 <- CQ2[CQ2$Daytime==1,]
## Fit kmeans to the second quarter day trips 
fitCQ2H1p <- kmeans(cbind(CQ2H1$Pickup_longitude, CQ2H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ2H1d <- kmeans(cbind(CQ2H1$Dropoff_longitude, CQ2H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ2H1p$cluster, dropoff = fitCQ2H1d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q2DayData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ2H1$pCluster <- fitCQ2H1p$cluster
CQ2H1$dCluster <- fitCQ2H1d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ2H1p$centers[,1],fitCQ2H1p$centers[,2], col=2, lwd=4, 
     type='p', main='Q2 Day Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ2H1d$centers[,1],fitCQ2H1d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ2H1p$centers[,1],Pickup_latitude=fitCQ2H1p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ2H1d$centers[,1],Dropoff_latitude=fitCQ2H1d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ2Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ2Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ3H0 <- CQ3[CQ3$Daytime==0,]
## Fit kmeans to the third quarter day trips 
fitCQ3H0p <- kmeans(cbind(CQ3H0$Pickup_longitude, CQ3H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H0d <- kmeans(cbind(CQ3H0$Dropoff_longitude, CQ3H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ3H0p$cluster, dropoff = fitCQ3H0d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q3NightData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ3H0$pCluster <- fitCQ3H0p$cluster
CQ3H0$dCluster <- fitCQ3H0d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ3H0p$centers[,1],fitCQ3H0p$centers[,2], col=2, lwd=4, 
     type='p', main='Q3 Night Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ3H0d$centers[,1],fitCQ3H0d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ3H0p$centers[,1],Pickup_latitude=fitCQ3H0p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ3H0d$centers[,1],Dropoff_latitude=fitCQ3H0d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ3H1 <- CQ3[CQ3$Daytime==1,]
## Fit kmeans to the third quarter day trips 
fitCQ3H1p <- kmeans(cbind(CQ3H1$Pickup_longitude, CQ3H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ3H1d <- kmeans(cbind(CQ3H1$Dropoff_longitude, CQ3H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ3H1p$cluster, dropoff = fitCQ3H1d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q3DayData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ3H1$pCluster <- fitCQ3H1p$cluster
CQ3H1$dCluster <- fitCQ3H1d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ3H1p$centers[,1],fitCQ3H1p$centers[,2], col=2, lwd=4, 
     type='p', main='Q3 Day Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ3H1d$centers[,1],fitCQ3H1d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ3H1p$centers[,1],Pickup_latitude=fitCQ3H1p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ3H1d$centers[,1],Dropoff_latitude=fitCQ3H1d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ4H0 <- CQ4[CQ4$Daytime==0,]
## Fit kmeans to the fourth quarter day trips 
fitCQ4H0p <- kmeans(cbind(CQ4H0$Pickup_longitude, CQ4H0$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H0d <- kmeans(cbind(CQ4H0$Dropoff_longitude, CQ4H0$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ4H0p$cluster, dropoff = fitCQ4H0d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q4NightData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

CQ4H0$pCluster <- fitCQ4H0p$cluster
CQ4H0$dCluster <- fitCQ4H0d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(fitCQ4H0p$centers[,1],fitCQ4H0p$centers[,2], col=2, lwd=4, 
     type='p', main='Q4 Night Data', 
     xlab='Pickup longitude', ylab='Pickup latitude', 
     xlim=c(lon_min,lon_max),
     ylim=c(lat_min,lat_max))
points(fitCQ4H0d$centers[,1],fitCQ4H0d$centers[,2],col=3,lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ4H0p$centers[,1],Pickup_latitude=fitCQ4H0p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ4H0d$centers[,1],Dropoff_latitude=fitCQ4H0d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)

CQ4H1 <- CQ4[CQ4$Daytime==1,]
## Fit kmeans to the fourth quarter day trips 
fitCQ4H1p <- kmeans(cbind(CQ4H1$Pickup_longitude, CQ4H1$Pickup_latitude), 
                    6, nstart = 10, iter.max = 20)
fitCQ4H1d <- kmeans(cbind(CQ4H1$Dropoff_longitude, CQ4H1$Dropoff_latitude), 
                    6, nstart = 10, iter.max = 20)

CC <- data.frame(pickup = fitCQ4H1p$cluster, dropoff = fitCQ4H1d$cluster)
CZ <- data.frame(pCluster = rep(0,36), dCluster = rep(0,36), Count = rep(0,36))

for(i in c(1:6)) {
  for(j in c(1:6)) {
    CZ$pCluster[6*(i-1)+j] = i
    CZ$dCluster[6*(i-1)+j] = j
    CZ$Count[6*(i-1)+j] <- sum(CC$pickup == i & CC$dropoff == j)
  }
}

## ----------------------------------------------
CZ <- CZ[order(CZ$Count, decreasing = TRUE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]

map <- data.frame(p = c(1:6), d=rep(0,6))
map$d <- CZ$dCluster[seq(1,36,6)]

CZ$d_old <- CZ$dCluster

CZ$dCluster[CZ$d_old==map$d[1]] <- rep(1,6)
CZ$dCluster[CZ$d_old==map$d[2]] <- rep(2,6)
CZ$dCluster[CZ$d_old==map$d[3]] <- rep(3,6)
CZ$dCluster[CZ$d_old==map$d[4]] <- rep(4,6)
CZ$dCluster[CZ$d_old==map$d[5]] <- rep(5,6)
CZ$dCluster[CZ$d_old==map$d[6]] <- rep(6,6)

rm(map)

CZ <- CZ[order(CZ$dCluster, decreasing = FALSE),]
CZ <- CZ[order(CZ$pCluster, decreasing = FALSE),]
## ----------------------------------------------

write.csv(CZ, file = "Connections\\Q4DayData.csv", row.names = FALSE)
rm(CC)
rm(CZ)

#CQ4H1$pCluster <- fitCQ4H1p$cluster
#CQ4H1$dCluster <- fitCQ4H1d$cluster

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(CQ4H1$Pickup_longitude, CQ4H1$Pickup_latitude, 
     type='p', main='Q4 Day Data', col=c(fitCQ4H1p$cluster), 
     xlab='Pickup longitude', ylab='Pickup latitude')#, 
     #xlim=c(lon_min,lon_max),
     #ylim=c(lat_min,lat_max))
points(fitCQ4H1p$centers[,1],fitCQ4H1p$centers[,2],col=c(2:7),lwd=4)

par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(CQ4H1$Dropoff_longitude, CQ4H1$Dropoff_latitude, 
     type='p', main='Q4 Day Data', col=c(fitCQ4H1d$cluster), 
     xlab='Dropoff longitude', ylab='Dropoff latitude')
points(fitCQ4H1d$centers[,1],fitCQ4H1d$centers[,2],col=c(2:7),lwd=4)

ptmp <- data.frame(Pickup_longitude=fitCQ4H1p$centers[,1],Pickup_latitude=fitCQ4H1p$centers[,2])
dtmp <- data.frame(Dropoff_longitude=fitCQ4H1d$centers[,1],Dropoff_latitude=fitCQ4H1d$centers[,2])
write.csv(ptmp, file = "ClusterCenters\\pCentersCQ4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterCenters\\dCentersCQ4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
