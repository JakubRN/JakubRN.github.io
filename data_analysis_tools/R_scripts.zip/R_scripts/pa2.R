# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
T <- read.csv("2015_Green_Taxi_Trip_Data.csv", sep=',', head=FALSE, nrows=1e6, #skip=12e6, 
              colClasses=c("NULL",NA,NA,"NULL",rep(NA,7),rep("NULL",7),NA,NA,NA))
C <- T[order(T$pickup_datetime),]
#write.csv(C, file = "pa2dat01.csv", row.names = FALSE)
C$pickup_datetime <- as.POSIXct(C$pickup_datetime,format='%m/%d/%Y %I:%M:%S %p',tz='GMT')
C$dropoff_datetime <- as.POSIXct(C$dropoff_datetime,format='%m/%d/%Y %I:%M:%S %p',tz='GMT')
# Eliminate rows without projection data 
C <- C[(C$Pickup_longitude != 0 & C$Pickup_latitude != 0 & C$Dropoff_longitude != 0 & 
         C$Dropoff_latitude != 0),]
#write.csv(C, file = "pa2dat02.csv", row.names = FALSE)
###################################################################################
###################################################################################
# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
C3 <- read.csv("pa5dat02.csv", sep=',', head=TRUE)
C3$pickup_datetime <- as.POSIXct(C3$pickup_datetime,tz='GMT')
C3$dropoff_datetime <- as.POSIXct(C3$dropoff_datetime,tz='GMT')
#C3 <- C3[sample(nrow(C3), 1e5), ]
#C3 <- C3[order(C3$pickup_datetime),]
#plot(C$pickup_datetime[1:100],C$Total_amount[1:100])
require(lubridate)
Z <- data.frame(PickupHour=hour(C3$pickup_datetime), PickupDay=day(C3$pickup_datetime), 
                PickupMonth=month(C3$pickup_datetime), DropoffHour=hour(C3$dropoff_datetime), 
                DropoffDay=day(C3$dropoff_datetime), DropoffMonth=month(C3$dropoff_datetime), 
                Amount=C3$Total_amount)
X <- data.frame(Hour=c(0:23),Count=rep(0,24),Amount=rep(0,24))
for(i in c(1:24)) {
  X$Count[i] <- sum(as.numeric(Z$PickupHour==i-1))
  X$Amount[i] <- sum(Z$Amount[Z$PickupHour==i-1])
}
Y <- data.frame(Month=c(1:12),Count=rep(0,12),Amount=rep(0,12))
for(i in c(1:12)) {
  Y$Count[i] <- sum(as.numeric(Z$PickupMonth==i))
  Y$Amount[i] <- sum(Z$Amount[Z$PickupMonth==i])
}
# Check only for 2015 
startDate = as.Date('2015-01-01',tz='GMT')
endDate = as.Date('2015-12-31',tz='GMT')
D <- 0
E <- 0
counter <- 1
for(i in c(startDate:endDate)) {
  E[counter] <- sum(as.numeric(as.Date(C3$pickup_datetime)==i)) 
                               #& C3$Daytime==1))
  #D[counter] <- sum(C3$Total_amount[i==as.Date(C3$pickup_datetime)])
  counter <- counter + 1
}
DayCount <- data.frame(Day = seq(as.Date("2015-01-01"), 
                                 as.Date("2015-12-31"), 
                                 by="days"), Count = E)#, Amount=D)
rm(D,E)
library(DescTools)
par(mfrow=c(1,1), mar=c(3.3,3.3,2,1),mgp=c(2,0.7,0))
plot(DayCount$Day, DayCount$Count, col=1, type='l', 
     main='Green Taxi Trip Count', xlab='Date', ylab='Count', 
     ylim=c(0,max(DayCount$Count)))
#lines(DayCount$Day, E, col=2, lwd=2)
legend("topright", inset=.02, c("Day", "Night"), 
       horiz=FALSE, col=c(2,4), lty=c(1,1), lwd=c(1,1), cex=0.8)
#write.csv(DayCount, file = "pa5dat03.csv", row.names = FALSE)
#####################################################################



