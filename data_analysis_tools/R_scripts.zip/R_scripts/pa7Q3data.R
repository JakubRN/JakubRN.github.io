#############################################################################
XQ3H0 <- CQ3H0[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ3H0p <- XQ3H0[XQ3H0$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ3H0d <- XQ3H0[XQ3H0$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ3H0p)
#write(exportJson, "ClusterData\\pC1Q3Night.json")
#rm(exportJson)
#exportJson <- toJSON(XQ3H0d)
#write(exportJson, "ClusterData\\dC1Q3Night.json")
ptmp <- XQ3H0p[sample(nrow(XQ3H0p), floor(0.15*dim(XQ3H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ3H0d[sample(nrow(XQ3H0d), floor(0.15*dim(XQ3H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
XQ3H1 <- CQ3H1[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ3H1p <- XQ3H1[XQ3H1$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ3H1d <- XQ3H1[XQ3H1$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ3H1p)
#write(exportJson, "ClusterData\\pC1Q3Day.json")
#rm(exportJson)
#exportJson <- toJSON(XQ3H1d)
#write(exportJson, "ClusterData\\dC1Q3Day.json")
ptmp <- XQ3H1p[sample(nrow(XQ3H1p), floor(0.15*dim(XQ3H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ3H1d[sample(nrow(XQ3H1d), floor(0.15*dim(XQ3H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q3H0 <- CQ3H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q3H0p <- X2Q3H0[X2Q3H0$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q3H0d <- X2Q3H0[X2Q3H0$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q3H0p[sample(nrow(X2Q3H0p), floor(0.15*dim(X2Q3H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q3H0d[sample(nrow(X2Q3H0d), floor(0.15*dim(X2Q3H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q3H1 <- CQ3H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q3H1p <- X2Q3H1[X2Q3H1$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q3H1d <- X2Q3H1[X2Q3H1$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q3H1p[sample(nrow(X2Q3H1p), floor(0.15*dim(X2Q3H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q3H1d[sample(nrow(X2Q3H1d), floor(0.15*dim(X2Q3H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q3H0 <- CQ3H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q3H0p <- X3Q3H0[X3Q3H0$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q3H0d <- X3Q3H0[X3Q3H0$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q3H0p[sample(nrow(X3Q3H0p), floor(0.15*dim(X3Q3H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q3H0d[sample(nrow(X3Q3H0d), floor(0.15*dim(X3Q3H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q3H1 <- CQ3H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q3H1p <- X3Q3H1[X3Q3H1$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q3H1d <- X3Q3H1[X3Q3H1$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q3H1p[sample(nrow(X3Q3H1p), floor(0.15*dim(X3Q3H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q3H1d[sample(nrow(X3Q3H1d), floor(0.15*dim(X3Q3H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q3H0 <- CQ3H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q3H0p <- X4Q3H0[X4Q3H0$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q3H0d <- X4Q3H0[X4Q3H0$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q3H0p[sample(nrow(X4Q3H0p), floor(0.15*dim(X4Q3H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q3H0d[sample(nrow(X4Q3H0d), floor(0.15*dim(X4Q3H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q3H1 <- CQ3H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q3H1p <- X4Q3H1[X4Q3H1$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q3H1d <- X4Q3H1[X4Q3H1$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q3H1p[sample(nrow(X4Q3H1p), floor(0.15*dim(X4Q3H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q3H1d[sample(nrow(X4Q3H1d), floor(0.15*dim(X4Q3H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q3H0 <- CQ3H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q3H0p <- X5Q3H0[X5Q3H0$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q3H0d <- X5Q3H0[X5Q3H0$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q3H0p[sample(nrow(X5Q3H0p), floor(0.15*dim(X5Q3H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q3H0d[sample(nrow(X5Q3H0d), floor(0.15*dim(X5Q3H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q3H1 <- CQ3H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q3H1p <- X5Q3H1[X5Q3H1$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q3H1d <- X5Q3H1[X5Q3H1$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q3H1p[sample(nrow(X5Q3H1p), floor(0.15*dim(X5Q3H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q3H1d[sample(nrow(X5Q3H1d), floor(0.15*dim(X5Q3H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q3H0 <- CQ3H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q3H0p <- X6Q3H0[X6Q3H0$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q3H0d <- X6Q3H0[X6Q3H0$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q3H0p[sample(nrow(X6Q3H0p), floor(0.15*dim(X6Q3H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q3H0d[sample(nrow(X6Q3H0d), floor(0.15*dim(X6Q3H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q3Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q3Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q3H1 <- CQ3H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q3H1p <- X6Q3H1[X6Q3H1$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q3H1d <- X6Q3H1[X6Q3H1$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q3H1p[sample(nrow(X6Q3H1p), floor(0.15*dim(X6Q3H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q3H1d[sample(nrow(X6Q3H1d), floor(0.15*dim(X6Q3H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q3Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q3Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
