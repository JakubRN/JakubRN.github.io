# Clear environment 
rm(list=ls())
# Change directory in R 
setwd("C:\\Users\\George\\Documents\\DTU\\SocialDataAnalysisAndVisualization\\workspace2\\ProjectAssignment")
T <- read.csv("2015_Green_Taxi_Trip_Data.csv", sep=',', head=TRUE, #nrows=4e6, skip=12e6, 
              colClasses=c("NULL",NA,NA,"NULL",rep(NA,7),rep("NULL",7),NA,NA,NA))
C <- T[order(T$pickup_datetime),]
C$pickup_datetime <- as.POSIXct(C$pickup_datetime,format='%m/%d/%Y %I:%M:%S %p',tz='GMT')
C$dropoff_datetime <- as.POSIXct(C$dropoff_datetime,format='%m/%d/%Y %I:%M:%S %p',tz='GMT')
# Eliminate rows without projection data 
C <- C[(C$Pickup_longitude != 0 & C$Pickup_latitude != 0 & C$Dropoff_longitude != 0 & 
          C$Dropoff_latitude != 0),]

CS <- C[sample(nrow(C), 2e6), ]
CS2 <- CS[order(CS$pickup_datetime),]

# Check only for 2015 
startDate = as.Date('2015-12-01',tz='GMT')
endDate = as.Date('2015-12-31',tz='GMT')

rm(CC)
CC <- C[as.Date(C$pickup_datetime) >= startDate & as.Date(C$pickup_datetime) <= endDate, ]

rm(CZ)
CZ <- CC[sample(nrow(CC), 1e5), ]
CZ12 <- CZ[order(CZ$pickup_datetime),]

C3 <- rbind(CZ1,CZ2,CZ3,CZ4,CZ5,CZ6,CZ7,CZ8,CZ9,CZ10,CZ11,CZ12)

#write.csv(C3, file = "pa5dat01.csv", row.names = FALSE)

