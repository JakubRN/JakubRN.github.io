#############################################################################
XQ4H0 <- CQ4H0[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ4H0p <- XQ4H0[XQ4H0$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ4H0d <- XQ4H0[XQ4H0$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ4H0p)
#write(exportJson, "ClusterData\\pC1Q4Night.json")
#rm(exportJson)
#exportJson <- toJSON(XQ4H0d)
#write(exportJson, "ClusterData\\dC1Q4Night.json")
ptmp <- XQ4H0p[sample(nrow(XQ4H0p), floor(0.15*dim(XQ4H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ4H0d[sample(nrow(XQ4H0d), floor(0.15*dim(XQ4H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
XQ4H1 <- CQ4H1[,c("Pickup_longitude","Pickup_latitude",
                  "Dropoff_longitude","Dropoff_latitude",
                  "pCluster","dCluster")]
XQ4H1p <- XQ4H1[XQ4H1$pCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "dCluster")]
XQ4H1d <- XQ4H1[XQ4H1$dCluster==1,c("Pickup_longitude","Pickup_latitude",
                                    "Dropoff_longitude","Dropoff_latitude",
                                    "pCluster")]
#rm(exportJson)
#exportJson <- toJSON(XQ4H1p)
#write(exportJson, "ClusterData\\pC1Q4Day.json")
#rm(exportJson)
#exportJson <- toJSON(XQ4H1d)
#write(exportJson, "ClusterData\\dC1Q4Day.json")
ptmp <- XQ4H1p[sample(nrow(XQ4H1p), floor(0.15*dim(XQ4H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- XQ4H1d[sample(nrow(XQ4H1d), floor(0.15*dim(XQ4H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC1Q4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC1Q4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q4H0 <- CQ4H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q4H0p <- X2Q4H0[X2Q4H0$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q4H0d <- X2Q4H0[X2Q4H0$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q4H0p[sample(nrow(X2Q4H0p), floor(0.15*dim(X2Q4H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q4H0d[sample(nrow(X2Q4H0d), floor(0.15*dim(X2Q4H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X2Q4H1 <- CQ4H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X2Q4H1p <- X2Q4H1[X2Q4H1$pCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X2Q4H1d <- X2Q4H1[X2Q4H1$dCluster==2,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X2Q4H1p[sample(nrow(X2Q4H1p), floor(0.15*dim(X2Q4H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X2Q4H1d[sample(nrow(X2Q4H1d), floor(0.15*dim(X2Q4H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC2Q4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC2Q4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q4H0 <- CQ4H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q4H0p <- X3Q4H0[X3Q4H0$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q4H0d <- X3Q4H0[X3Q4H0$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q4H0p[sample(nrow(X3Q4H0p), floor(0.15*dim(X3Q4H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q4H0d[sample(nrow(X3Q4H0d), floor(0.15*dim(X3Q4H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X3Q4H1 <- CQ4H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X3Q4H1p <- X3Q4H1[X3Q4H1$pCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X3Q4H1d <- X3Q4H1[X3Q4H1$dCluster==3,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X3Q4H1p[sample(nrow(X3Q4H1p), floor(0.15*dim(X3Q4H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X3Q4H1d[sample(nrow(X3Q4H1d), floor(0.15*dim(X3Q4H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC3Q4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC3Q4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q4H0 <- CQ4H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q4H0p <- X4Q4H0[X4Q4H0$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q4H0d <- X4Q4H0[X4Q4H0$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q4H0p[sample(nrow(X4Q4H0p), floor(0.15*dim(X4Q4H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q4H0d[sample(nrow(X4Q4H0d), floor(0.15*dim(X4Q4H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X4Q4H1 <- CQ4H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X4Q4H1p <- X4Q4H1[X4Q4H1$pCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X4Q4H1d <- X4Q4H1[X4Q4H1$dCluster==4,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X4Q4H1p[sample(nrow(X4Q4H1p), floor(0.15*dim(X4Q4H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X4Q4H1d[sample(nrow(X4Q4H1d), floor(0.15*dim(X4Q4H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC4Q4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC4Q4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q4H0 <- CQ4H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q4H0p <- X5Q4H0[X5Q4H0$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q4H0d <- X5Q4H0[X5Q4H0$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q4H0p[sample(nrow(X5Q4H0p), floor(0.15*dim(X5Q4H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q4H0d[sample(nrow(X5Q4H0d), floor(0.15*dim(X5Q4H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X5Q4H1 <- CQ4H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X5Q4H1p <- X5Q4H1[X5Q4H1$pCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X5Q4H1d <- X5Q4H1[X5Q4H1$dCluster==5,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X5Q4H1p[sample(nrow(X5Q4H1p), floor(0.15*dim(X5Q4H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X5Q4H1d[sample(nrow(X5Q4H1d), floor(0.15*dim(X5Q4H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC5Q4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC5Q4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q4H0 <- CQ4H0[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q4H0p <- X6Q4H0[X6Q4H0$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q4H0d <- X6Q4H0[X6Q4H0$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q4H0p[sample(nrow(X6Q4H0p), floor(0.15*dim(X6Q4H0p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q4H0d[sample(nrow(X6Q4H0d), floor(0.15*dim(X6Q4H0d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q4Night.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q4Night.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
X6Q4H1 <- CQ4H1[,c("Pickup_longitude","Pickup_latitude",
                   "Dropoff_longitude","Dropoff_latitude",
                   "pCluster","dCluster")]
X6Q4H1p <- X6Q4H1[X6Q4H1$pCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "dCluster")]
X6Q4H1d <- X6Q4H1[X6Q4H1$dCluster==6,c("Pickup_longitude","Pickup_latitude",
                                       "Dropoff_longitude","Dropoff_latitude",
                                       "pCluster")]
ptmp <- X6Q4H1p[sample(nrow(X6Q4H1p), floor(0.15*dim(X6Q4H1p)[1])), ]
ptmp <- ptmp[order(as.numeric(row.names(ptmp))), ]
dtmp <- X6Q4H1d[sample(nrow(X6Q4H1d), floor(0.15*dim(X6Q4H1d)[1])), ]
dtmp <- dtmp[order(as.numeric(row.names(dtmp))), ]
write.csv(ptmp, file = "ClusterData\\pC6Q4Day.csv", row.names = FALSE)
write.csv(dtmp, file = "ClusterData\\dC6Q4Day.csv", row.names = FALSE)
rm(ptmp)
rm(dtmp)
#############################################################################
